import React, { useState, useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend
} from "recharts";

/* ------------------------------------------------------------------ *
 *  PCP LONG-RUN PLANNER
 *  One question: over a whole run of cars, does a lower rate or a
 *  bigger deposit save you more?
 *
 *  Visual language: dealer carbonless-copy (NCR) proposal pad.
 *  Pale blue-grey stock, black ink, hairline field boxes, red stamp.
 *  Signature element: the rate-card grid on the "Deposit x rate" tab.
 * ------------------------------------------------------------------ */

const C = {
  paper:    "#E3E9EA",
  well:     "#F3F6F6",
  band:     "#D3DBDD",
  ink:      "#14181A",
  inkSoft:  "#5C666B",
  rule:     "#A6B1B5",
  stamp:    "#B32F27",
  preprint: "#1E4A6E",
  gold:     "#8A6A1F",
};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&family=Roboto+Mono:wght@400;500;700&display=swap');

.pcp * { box-sizing: border-box; }
.pcp {
  background: ${C.paper};
  color: ${C.ink};
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  min-height: 100%;
  padding: 18px 12px 56px;
  -webkit-font-smoothing: antialiased;
}
.sheet { max-width: 1120px; margin: 0 auto; background: ${C.paper}; border: 1px solid ${C.ink}; box-shadow: 3px 3px 0 rgba(20,24,26,.18); }
.cond { font-family: "Roboto Condensed", "Arial Narrow", Arial, sans-serif; }
.mono { font-family: "Roboto Mono", ui-monospace, Menlo, Consolas, monospace; font-variant-numeric: tabular-nums; }

.hdr { border-bottom: 1px solid ${C.ink}; padding: 12px 16px 10px; background: ${C.band}; }
.hdr-t { font-size: 19px; font-weight: 700; letter-spacing: .15em; text-transform: uppercase; }
.hdr-s { font-size: 11px; letter-spacing: .09em; color: ${C.inkSoft}; text-transform: uppercase; margin-top: 3px; }

/* ---- top input bar ---- */
.bar { border-bottom: 1px solid ${C.ink}; padding: 13px 16px 14px; display: grid; gap: 14px 18px; grid-template-columns: repeat(3, 1fr); }
@media (max-width: 760px) { .bar { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 460px) { .bar { grid-template-columns: 1fr; } }
.span2 { grid-column: span 2; }
@media (max-width: 460px) { .span2 { grid-column: span 1; } }

.fl { font-size: 10px; letter-spacing: .11em; text-transform: uppercase; color: ${C.inkSoft}; margin-bottom: 4px; display: flex; justify-content: space-between; gap: 8px; }
.fw { display: flex; align-items: center; background: ${C.well}; border: 1px solid ${C.rule}; border-radius: 1px; padding: 6px 8px; }
.fw:focus-within { border-color: ${C.ink}; box-shadow: 0 0 0 2px rgba(30,74,110,.25); }
.fw input { flex: 1; min-width: 0; background: transparent; border: none; outline: none; color: ${C.ink}; font-size: 15px; font-weight: 500; font-family: "Roboto Mono", ui-monospace, monospace; font-variant-numeric: tabular-nums; }
.fx { color: ${C.inkSoft}; font-size: 12px; }
.hint { font-size: 10.5px; color: ${C.inkSoft}; margin-top: 4px; line-height: 1.45; }
input[type=range] { width: 100%; accent-color: ${C.stamp}; margin: 7px 0 0; height: 18px; }

.chips { display: flex; gap: 5px; flex-wrap: wrap; }
.chip { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 11px; letter-spacing: .09em; text-transform: uppercase; padding: 6px 9px; border: 1px solid ${C.rule}; background: ${C.well}; color: ${C.inkSoft}; cursor: pointer; border-radius: 1px; }
.chip:hover { border-color: ${C.ink}; color: ${C.ink}; }
.chip.on { background: ${C.ink}; border-color: ${C.ink}; color: ${C.paper}; font-weight: 700; }

/* ---- headline ---- */
.quote { padding: 15px 16px 14px; border-bottom: 1px solid ${C.ink}; display: flex; gap: 20px; align-items: center; flex-wrap: wrap; }
.stamp { border: 2px solid ${C.stamp}; box-shadow: inset 0 0 0 2px ${C.paper}, inset 0 0 0 3px ${C.stamp}; padding: 9px 16px 7px; transform: rotate(-2.4deg); color: ${C.stamp}; text-align: center; flex: 0 0 auto; }
.stamp-l { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 10px; letter-spacing: .2em; font-weight: 700; }
.stamp-f { font-family: "Roboto Mono", monospace; font-size: 38px; font-weight: 700; line-height: 1.05; letter-spacing: -.02em; }
.stamp-s { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 10px; letter-spacing: .14em; }
@media (max-width: 520px) { .stamp-f { font-size: 31px; } }

.kv { display: grid; grid-template-columns: repeat(auto-fit, minmax(124px, 1fr)); gap: 12px 18px; flex: 1 1 280px; }
.kv-l { font-size: 9.5px; letter-spacing: .11em; text-transform: uppercase; color: ${C.inkSoft}; }
.kv-v { font-family: "Roboto Mono", monospace; font-size: 16px; font-weight: 500; font-variant-numeric: tabular-nums; margin-top: 2px; }
.kv-n { font-size: 10px; color: ${C.inkSoft}; }

/* ---- tabs ---- */
.tabs { display: flex; border-bottom: 1px solid ${C.ink}; background: ${C.band}; overflow-x: auto; }
.tab { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 12px; letter-spacing: .13em; text-transform: uppercase; padding: 9px 14px; background: transparent; border: none; border-right: 1px solid ${C.rule}; color: ${C.inkSoft}; cursor: pointer; white-space: nowrap; }
.tab:hover { color: ${C.ink}; }
.tab.on { background: ${C.paper}; color: ${C.ink}; font-weight: 700; box-shadow: inset 0 -3px 0 ${C.stamp}; }

.pane { padding: 14px 16px 18px; }
.pane-h { font-size: 12px; letter-spacing: .16em; text-transform: uppercase; font-weight: 700; margin-bottom: 3px; }
.pane-s { font-size: 12.5px; color: ${C.inkSoft}; margin-bottom: 13px; line-height: 1.55; max-width: 70ch; }

/* ---- tables ---- */
.tblwrap { overflow-x: auto; border: 1px solid ${C.rule}; background: ${C.well}; }
table.t { border-collapse: collapse; width: 100%; font-family: "Roboto Mono", monospace; font-size: 12.5px; font-variant-numeric: tabular-nums; }
table.t th { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 10px; letter-spacing: .09em; text-transform: uppercase; text-align: right; padding: 7px 10px; color: ${C.preprint}; border-bottom: 1px solid ${C.ink}; white-space: nowrap; font-weight: 700; }
table.t th:first-child, table.t td:first-child { text-align: left; }
table.t td { padding: 6px 10px; text-align: right; border-bottom: 1px solid rgba(166,177,181,.55); white-space: nowrap; }
table.t tr:last-child td { border-bottom: none; }
table.t tr.here td { background: rgba(179,47,39,.09); font-weight: 700; }
table.t tr.here td:first-child::before { content: "\\25B8 "; color: ${C.stamp}; }
.best { color: ${C.stamp}; font-weight: 700; }
.save { color: ${C.preprint}; }
.cost { color: ${C.stamp}; }

.levers { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
@media (max-width: 860px) { .levers { grid-template-columns: 1fr; } }
.lv-h { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 11px; letter-spacing: .14em; text-transform: uppercase; font-weight: 700; margin-bottom: 6px; }
.lv-h span { color: ${C.inkSoft}; font-weight: 400; letter-spacing: .04em; text-transform: none; }

/* ---- the grid (signature) ---- */
.gwrap { overflow-x: auto; border: 1px solid ${C.ink}; background: ${C.well}; }
table.g { border-collapse: collapse; width: 100%; font-family: "Roboto Mono", monospace; font-variant-numeric: tabular-nums; }
table.g th { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: ${C.preprint}; font-weight: 700; padding: 7px 8px; border-bottom: 1px solid ${C.ink}; border-right: 1px solid ${C.rule}; white-space: nowrap; }
table.g th.rh { text-align: left; border-right: 1px solid ${C.ink}; border-bottom: 1px solid rgba(166,177,181,.55); font-size: 11px; color: ${C.ink}; }
table.g th.rh small { display: block; color: ${C.inkSoft}; font-weight: 400; letter-spacing: .04em; }
table.g th.corner { border-right: 1px solid ${C.ink}; text-align: left; }
table.g td { padding: 7px 6px; text-align: center; border-right: 1px solid rgba(166,177,181,.45); border-bottom: 1px solid rgba(166,177,181,.45); min-width: 86px; }
.gc-v { font-size: 12.5px; font-weight: 500; }
.gc-d { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 9.5px; letter-spacing: .07em; color: ${C.inkSoft}; margin-top: 2px; text-transform: uppercase; }
.gc-best { outline: 2px solid ${C.preprint}; outline-offset: -2px; }
.gc-best .gc-d { color: ${C.preprint}; font-weight: 700; }
.gc-you { outline: 2px solid ${C.ink}; outline-offset: -2px; }
.gc-you .gc-v::after { content: " \\25C2"; color: ${C.ink}; }

.note { border-left: 3px solid ${C.stamp}; background: rgba(179,47,39,.06); padding: 10px 12px; font-size: 12.5px; line-height: 1.6; margin-top: 14px; }
.warn { border-left: 3px solid ${C.preprint}; background: rgba(30,74,110,.08); padding: 10px 12px; font-size: 12.5px; line-height: 1.5; margin-bottom: 12px; }
.fine { font-size: 10.5px; color: ${C.inkSoft}; line-height: 1.6; padding: 12px 16px; border-top: 1px solid ${C.ink}; background: ${C.band}; }
.rule { height: 0; border-top: 1px dashed ${C.rule}; margin: 16px 0; }
.btn { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 11px; letter-spacing: .12em; text-transform: uppercase; padding: 6px 11px; border: 1px solid ${C.ink}; background: ${C.well}; color: ${C.ink}; cursor: pointer; border-radius: 1px; }
.btn:hover { background: ${C.ink}; color: ${C.paper}; }
.btn.gh { border-color: ${C.rule}; color: ${C.inkSoft}; }
.setgrid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 4px 20px; }
.setgrp { font-family: "Roboto Condensed", Arial, sans-serif; font-size: 11px; letter-spacing: .15em; text-transform: uppercase; font-weight: 700; color: ${C.stamp}; margin: 4px 0 8px; }
.fld { margin-bottom: 13px; }
button:focus-visible, input:focus-visible { outline: 2px solid ${C.preprint}; outline-offset: 2px; }
@media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
`;

/* ============================ maths ============================ */

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

const gbp = (n, dp = 0) =>
  (n < 0 ? "-£" : "£") +
  Math.abs(n).toLocaleString("en-GB", { minimumFractionDigits: dp, maximumFractionDigits: dp });

const gbpK = (n) => (Math.abs(n) >= 10000 ? "£" + (n / 1000).toFixed(1) + "k" : gbp(n));

// Retained value of a mainstream car at 10,000 miles/yr, % of new price.
const RV_CURVE = [[0, 100], [12, 72], [24, 60], [36, 52], [48, 44], [60, 38], [72, 33], [84, 29],
                  [96, 25], [120, 19], [144, 14], [180, 10], [240, 7]];

function baseRetained(months) {
  if (months <= 0) return 100;
  for (let k = 1; k < RV_CURVE.length; k++) {
    const [m1, v1] = RV_CURVE[k - 1];
    const [m2, v2] = RV_CURVE[k];
    if (months <= m2) return v1 + ((v2 - v1) * (months - m1)) / (m2 - m1);
  }
  return RV_CURVE[RV_CURVE.length - 1][1];
}

// Mileage swing: ~0.4pp of new price per extra 1,000 miles/yr, per year of term.
function retainedPct(months, mileage) {
  const adj = -0.4 * ((mileage - 10000) / 1000) * (months / 12);
  return clamp(baseRetained(months) + adj, 10, 90);
}

// Funders pitch the balloon below forecast market value. That gap is your end-of-term equity.
function autoGmfv(price, months, mileage, caution = 8) {
  const v = ((price * retainedPct(months, mileage)) / 100) * (1 - caution / 100);
  return Math.round(v / 25) * 25;
}

function quote({ price, dep, contrib, apr, months, gmfv, optionFee }) {
  const i = Math.pow(1 + apr / 100, 1 / 12) - 1;
  const financed = Math.max(0, price - dep - contrib);
  const g = Math.min(gmfv, financed);            // no funder writes a balloon above the balance
  const af = i === 0 ? months : (1 - Math.pow(1 + i, -months)) / i;
  const pvB = i === 0 ? g : g / Math.pow(1 + i, months);
  const monthly = Math.max(0, (financed - pvB) / af);
  const finalPayment = g + optionFee;
  return {
    i, af, financed, gmfvUsed: g, monthly, finalPayment,
    costToChange: dep + monthly * months,
    totalPayable: dep + monthly * months + finalPayment,
    charge: monthly * months + finalPayment - financed,
    capped: gmfv > financed,
  };
}

function settlementAt(k, q, months, gmfv) {
  const rem = months - k;
  if (rem <= 0) return gmfv;
  const af = q.i === 0 ? rem : (1 - Math.pow(1 + q.i, -rem)) / q.i;
  const pvB = q.i === 0 ? gmfv : gmfv / Math.pow(1 + q.i, rem);
  return q.monthly * af + pvB;
}

/* ---------------- rolling PCP simulation ----------------
 * Successive deals across a fixed horizon. Equity at each hand-back
 * rolls into the next deposit. Negative equity is worth nothing but
 * costs nothing — the GMFV guarantee absorbs it.
 * ------------------------------------------------------- */

function simulateCycle({ T, horizonM, price0, infl, apr, mileage, firstDep, topUp,
                        contribPct, optionFee, sRate, caution }) {
  const s = Math.pow(1 + sRate / 100, 1 / 12) - 1;
  const disc = (m) => (s === 0 ? 1 : Math.pow(1 + s, -m));
  const cum = new Array(horizonM + 1).fill(0);   // nominal cash out
  let m = 0, nom = 0, pv = 0, interest = 0, cars = 0, carry = 0, residual = 0;
  let firstMonthly = 0, firstBalloon = 0, firstFinanced = 0;

  while (m < horizonM) {
    const p = price0 * Math.pow(1 + infl / 100, m / 12);
    const contrib = p * contribPct;
    const depCash = cars === 0 ? firstDep : topUp;
    const g = autoGmfv(p, T, mileage, caution);
    const qq = quote({ price: p, dep: depCash + carry, contrib, apr, months: T, gmfv: g, optionFee });
    if (cars === 0) { firstMonthly = qq.monthly; firstBalloon = qq.gmfvUsed; firstFinanced = qq.financed; }

    const full = m + T <= horizonM;
    const k = full ? T : horizonM - m;

    nom += depCash; pv += depCash * disc(m); cum[m] = nom;
    for (let j = 1; j <= k; j++) { nom += qq.monthly; pv += qq.monthly * disc(m + j); cum[m + j] = nom; }

    if (full) {
      interest += qq.monthly * T + qq.gmfvUsed - qq.financed;
      const valEnd = (p * retainedPct(T, mileage)) / 100;
      carry = Math.max(0, valEnd - qq.gmfvUsed);   // hand back and walk if it's underwater
      residual = carry;
    } else {
      const stl = settlementAt(k, qq, T, qq.gmfvUsed);
      interest += qq.monthly * k + stl - qq.financed;
      residual = (p * retainedPct(k, mileage)) / 100 - stl;
    }
    cars++; m += k;
  }
  return {
    T, cars, firstMonthly, firstBalloon, firstFinanced,
    cashIn: nom, residual, interest, cum,
    net: nom - residual,
    trueCost: pv - residual * disc(horizonM),
  };
}

function simulateCash({ horizonM, price0, infl, keepM, mileage, sRate }) {
  const s = Math.pow(1 + sRate / 100, 1 / 12) - 1;
  const disc = (m) => (s === 0 ? 1 : Math.pow(1 + s, -m));
  const cum = new Array(horizonM + 1).fill(0);
  let m = 0, nom = 0, pv = 0, cars = 0, carry = 0, residual = 0, firstOutlay = 0;

  while (m < horizonM) {
    const p = price0 * Math.pow(1 + infl / 100, m / 12);
    const outlay = Math.max(0, p - carry);
    if (cars === 0) firstOutlay = outlay;
    nom += outlay; pv += outlay * disc(m);
    const k = Math.min(keepM, horizonM - m);
    for (let j = 0; j <= k; j++) cum[m + j] = nom;
    const val = (p * retainedPct(k, mileage)) / 100;
    if (m + k >= horizonM) residual = val; else carry = val;
    cars++; m += k;
  }
  return { cars, firstOutlay, cashIn: nom, residual, interest: 0, cum,
           net: nom - residual, trueCost: pv - residual * disc(horizonM) };
}

/* ============================ bits ============================ */

function Field({ label, sub, value, onChange, prefix, suffix, step = 1, min, max, hint }) {
  return (
    <div className="fld">
      <div className="fl cond"><span>{label}</span>{sub && <span>{sub}</span>}</div>
      <div className="fw">
        {prefix && <span className="fx" style={{ marginRight: 5 }}>{prefix}</span>}
        <input type="number" value={value} step={step} min={min} max={max}
               onChange={(e) => onChange(e.target.value === "" ? 0 : parseFloat(e.target.value))} />
        {suffix && <span className="fx" style={{ marginLeft: 5 }}>{suffix}</span>}
      </div>
      {hint && <div className="hint">{hint}</div>}
    </div>
  );
}

function KV({ label, value, note }) {
  return (
    <div>
      <div className="kv-l cond">{label}</div>
      <div className="kv-v">{value}</div>
      {note && <div className="kv-n cond">{note}</div>}
    </div>
  );
}

function Delta({ v }) {
  if (Math.abs(v) < 1) return <span style={{ color: C.inkSoft }}>—</span>;
  return <span className={v < 0 ? "save" : "cost"}>{v < 0 ? "saves " : "costs "}{gbp(Math.abs(v))}</span>;
}

function ChartTip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div style={{ background: C.well, border: `1px solid ${C.ink}`, padding: "7px 9px",
                  fontSize: 12, fontFamily: "Roboto Mono, monospace" }}>
      <div style={{ color: C.inkSoft, marginBottom: 4 }}>Year {(label / 12).toFixed(1)}</div>
      {payload.map((p) => <div key={p.dataKey} style={{ color: p.color }}>{p.name}: {gbp(p.value)}</div>)}
    </div>
  );
}

const axis = { stroke: C.rule, tick: { fill: C.inkSoft, fontSize: 10, fontFamily: "Roboto Mono, monospace" } };

const DEFAULTS = {
  price: 32000, dep: 3000, apr: 9.9, changeYrs: 4, horizon: 16,
  mileage: 10000, contrib: 0, optionFee: 10, savingsRate: 4, countSavings: true,
  infl: 3, topUp: 0, caution: 8, keepYears: 8,
};

/* ============================ app ============================ */

export default function PCPPlanner() {
  const [price, setPrice] = useState(DEFAULTS.price);
  const [dep, setDep] = useState(DEFAULTS.dep);
  const [apr, setApr] = useState(DEFAULTS.apr);
  const [changeYrs, setChangeYrs] = useState(DEFAULTS.changeYrs);
  const [horizon, setHorizon] = useState(DEFAULTS.horizon);

  const [mileage, setMileage] = useState(DEFAULTS.mileage);
  const [contrib, setContrib] = useState(DEFAULTS.contrib);
  const [optionFee, setOptionFee] = useState(DEFAULTS.optionFee);
  const [savingsRate, setSavingsRate] = useState(DEFAULTS.savingsRate);
  const [countSavings, setCountSavings] = useState(DEFAULTS.countSavings);
  const [infl, setInfl] = useState(DEFAULTS.infl);
  const [topUp, setTopUp] = useState(DEFAULTS.topUp);
  const [caution, setCaution] = useState(DEFAULTS.caution);
  const [keepYears, setKeepYears] = useState(DEFAULTS.keepYears);

  const [tab, setTab] = useState("summary");
  const [gridMetric, setGridMetric] = useState("cost");

  const T = Math.round(changeYrs * 12);
  const horizonM = Math.round(horizon * 12);
  const sRate = countSavings ? savingsRate : 0;
  const contribPct = price > 0 ? contrib / price : 0;
  const costLabel = countSavings ? "True cost" : "Total cost";

  const args = { horizonM, price0: price, infl, mileage, topUp, contribPct, optionFee, sRate, caution };
  const mk = (d, a, term = T) => simulateCycle({ ...args, T: term, firstDep: d, apr: a });
  const deps = [horizonM, price, infl, mileage, topUp, contribPct, optionFee, sRate, caution, T, dep, apr];

  const mine = useMemo(() => mk(dep, apr), deps);          // eslint-disable-line
  const firstQuote = useMemo(
    () => quote({ price, dep, contrib, apr, months: T, gmfv: autoGmfv(price, T, mileage, caution), optionFee }),
    [price, dep, contrib, apr, T, mileage, caution, optionFee]
  );

  /* --- the two levers, sized against each other --- */
  const aprRows = useMemo(() => {
    const list = [0, 2.9, 4.9, 6.9, 8.9, 10.9, 12.9];
    if (!list.includes(apr)) list.push(apr);
    return [...new Set(list)].sort((a, b) => a - b).map((a) => ({ a, ...mk(dep, a) }));
  }, deps);                                                 // eslint-disable-line

  const depRows = useMemo(() => {
    const set = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3].map((p) => Math.round((price * p) / 250) * 250);
    if (!set.includes(dep)) set.push(dep);
    return [...new Set(set)].filter((d) => d >= 0).sort((a, b) => a - b).map((d) => ({ d, ...mk(d, apr) }));
  }, deps);                                                 // eslint-disable-line

  const twoPtDown = useMemo(() => mk(dep, Math.max(0, apr - 2)), deps);      // eslint-disable-line
  const twoKDown  = useMemo(() => mk(dep + 2000, apr), deps);                // eslint-disable-line
  const saveRate = mine.trueCost - twoPtDown.trueCost;
  const saveDep  = mine.trueCost - twoKDown.trueCost;

  /* --- signature: the deposit x rate rate-card --- */
  const grid = useMemo(() => {
    const aprs = [...new Set([0, 2.9, 4.9, 6.9, 8.9, 10.9, 12.9, apr])].sort((a, b) => a - b);
    const dps = [...new Set([0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
      .map((p) => Math.round((price * p) / 250) * 250).concat(dep))]
      .filter((d) => d >= 0).sort((a, b) => a - b);
    const cells = dps.map((d) => aprs.map((a) => {
      const r = mk(d, a);
      return { d, a, cost: r.trueCost, monthly: r.firstMonthly };
    }));
    const flat = cells.flat();
    const key = gridMetric === "cost" ? "cost" : "monthly";
    return { aprs, dps, cells,
             lo: Math.min(...flat.map((c) => c[key])),
             hi: Math.max(...flat.map((c) => c[key])), key };
  }, [...deps, gridMetric]);                                // eslint-disable-line

  /* --- timeline --- */
  const cash = useMemo(
    () => simulateCash({ horizonM, price0: price, infl, keepM: Math.round(keepYears * 12), mileage, sRate }),
    [horizonM, price, infl, keepYears, mileage, sRate]
  );
  const altRate = useMemo(() => mk(dep, Math.max(0, apr - 3)), deps);        // eslint-disable-line
  const altDep  = useMemo(() => mk(dep + 5000, apr), deps);                  // eslint-disable-line
  const timeline = useMemo(() => {
    const rows = [];
    for (let m = 0; m <= horizonM; m += 3)
      rows.push({ m, you: Math.round(mine.cum[m]), rate: Math.round(altRate.cum[m]),
                  depo: Math.round(altDep.cum[m]), cash: Math.round(cash.cum[m]) });
    return rows;
  }, [mine, altRate, altDep, cash, horizonM]);

  const freqs = useMemo(() => [24, 36, 48, 60, 72].map((t) => mk(dep, apr, t)), deps); // eslint-disable-line
  const freqBest = Math.min(...freqs.map((f) => f.trueCost));

  const resetAll = () => {
    setPrice(DEFAULTS.price); setDep(DEFAULTS.dep); setApr(DEFAULTS.apr);
    setChangeYrs(DEFAULTS.changeYrs); setHorizon(DEFAULTS.horizon);
    setMileage(DEFAULTS.mileage); setContrib(DEFAULTS.contrib); setOptionFee(DEFAULTS.optionFee);
    setSavingsRate(DEFAULTS.savingsRate); setCountSavings(DEFAULTS.countSavings);
    setInfl(DEFAULTS.infl); setTopUp(DEFAULTS.topUp); setCaution(DEFAULTS.caution);
    setKeepYears(DEFAULTS.keepYears);
  };

  const shade = (v) => {
    const t = grid.hi === grid.lo ? 0 : (v - grid.lo) / (grid.hi - grid.lo);
    return `rgba(179,47,39,${(0.02 + 0.32 * t).toFixed(3)})`;
  };

  const TABS = [["summary", "Summary"], ["grid", "Deposit × rate"],
                ["time", "Over time"], ["settings", "Settings"]];

  return (
    <div className="pcp">
      <style>{CSS}</style>
      <div className="sheet">

        <div className="hdr">
          <div className="hdr-t cond">PCP over the long run</div>
          <div className="hdr-s cond">
            {mine.cars} cars · {changeYrs} years each · {horizon} years in total · illustration only
          </div>
        </div>

        {/* ---------------- the only five things you need to set ---------------- */}
        <div className="bar">
          <div>
            <Field label="Car price" value={price} onChange={setPrice} prefix="£" step={250} min={0} />
          </div>
          <div>
            <Field label="Deposit" sub={price ? ((dep / price) * 100).toFixed(0) + "%" : ""}
                   value={dep} onChange={setDep} prefix="£" step={250} min={0} />
            <input type="range" min={0} max={Math.round(price * 0.4)} step={250} value={Math.min(dep, price * 0.4)}
                   onChange={(e) => setDep(parseFloat(e.target.value))} aria-label="Deposit" />
          </div>
          <div>
            <Field label="Interest rate" sub="APR" value={apr} onChange={setApr} suffix="%" step={0.1} min={0} max={30} />
            <input type="range" min={0} max={16} step={0.1} value={clamp(apr, 0, 16)}
                   onChange={(e) => setApr(parseFloat(e.target.value))} aria-label="APR" />
          </div>
          <div>
            <div className="fl cond"><span>Change car every</span></div>
            <div className="chips">
              {[2, 3, 4, 5, 6].map((y) => (
                <button key={y} className={"chip" + (changeYrs === y ? " on" : "")}
                        onClick={() => setChangeYrs(y)}>{y} yr</button>
              ))}
            </div>
          </div>
          <div>
            <div className="fl cond"><span>Look ahead</span></div>
            <div className="chips">
              {[8, 12, 16, 20].map((y) => (
                <button key={y} className={"chip" + (horizon === y ? " on" : "")}
                        onClick={() => setHorizon(y)}>{y} yrs</button>
              ))}
            </div>
            <div className="hint">Everything else has a sensible default. Change it under Settings.</div>
          </div>
        </div>

        {/* ---------------- headline ---------------- */}
        <div className="quote">
          <div className="stamp">
            <div className="stamp-l">Monthly payment</div>
            <div className="stamp-f">{gbp(mine.firstMonthly, 2)}</div>
            <div className="stamp-s">first car · {T} payments · {apr.toFixed(1)}% APR</div>
          </div>
          <div className="kv">
            <KV label={costLabel + ", " + horizon + " yrs"} value={gbp(mine.trueCost)}
                note={countSavings ? "in today's money" : "cash, less the car left"} />
            <KV label="Averaged per month" value={gbp(mine.trueCost / horizonM, 2)} note={`across all ${horizon} years`} />
            <KV label="Cash you hand over" value={gbp(mine.cashIn)} note={`deposit + ${horizonM} monthlies`} />
            <KV label="Interest & fees" value={gbp(mine.interest)} note={`over ${mine.cars} deals`} />
            <KV label="Left in the last car" value={gbp(mine.residual)} note={`equity at year ${horizon}`} />
            <KV label="Balloon, first car" value={gbp(firstQuote.finalPayment)} note="only if you buy it" />
          </div>
        </div>

        <div className="tabs">
          {TABS.map(([k, l]) => (
            <button key={k} className={"tab" + (tab === k ? " on" : "")} onClick={() => setTab(k)}>{l}</button>
          ))}
        </div>

        {/* ---------------- summary ---------------- */}
        {tab === "summary" && (
          <div className="pane">
            <div className="pane-h cond">Which lever actually saves you money</div>
            <div className="pane-s">
              Two things are usually up for negotiation: the rate and how much you put down. Over {horizon} years they do very
              different jobs. Both tables below change one thing at a time and leave everything else exactly as you have it.
            </div>

            <div className="levers">
              <div>
                <div className="lv-h">Move the rate <span>— deposit stays {gbp(dep)}</span></div>
                <div className="tblwrap">
                  <table className="t">
                    <thead><tr><th>APR</th><th>Monthly</th><th>{costLabel}</th><th>vs yours</th></tr></thead>
                    <tbody>
                      {aprRows.map((r) => (
                        <tr key={r.a} className={r.a === apr ? "here" : ""}>
                          <td>{r.a.toFixed(1)}%</td>
                          <td>{gbp(r.firstMonthly, 2)}</td>
                          <td>{gbp(r.trueCost)}</td>
                          <td><Delta v={r.trueCost - mine.trueCost} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <div className="lv-h">Move the deposit <span>— rate stays {apr.toFixed(1)}%</span></div>
                <div className="tblwrap">
                  <table className="t">
                    <thead><tr><th>Deposit</th><th>Monthly</th><th>{costLabel}</th><th>vs yours</th></tr></thead>
                    <tbody>
                      {depRows.map((r) => (
                        <tr key={r.d} className={r.d === dep ? "here" : ""}>
                          <td>{gbp(r.d)}</td>
                          <td>{gbp(r.firstMonthly, 2)}</td>
                          <td>{gbp(r.trueCost)}</td>
                          <td><Delta v={r.trueCost - mine.trueCost} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="note">
              Knocking <b>2 points off the rate</b> saves you <b>{gbp(Math.max(0, saveRate))}</b> over {horizon} years.
              Putting <b>£2,000 more down</b> {saveDep >= 0 ? <>saves <b>{gbp(saveDep)}</b></> : <>actually costs you <b>{gbp(-saveDep)}</b></>}
              {saveDep >= 0 && saveRate > 0 && <> — the rate is worth about <b>{(saveRate / Math.max(saveDep, 1)).toFixed(1)}×</b> as much, and it costs you nothing up front</>}.
              <div style={{ marginTop: 7 }}>
                Here's why. Your deposit only buys down the <i>first</i> car. From the second one on, every deal starts with the
                equity the last car handed back — the same equity whether you put £0 or £10,000 down at the beginning, because the
                guaranteed final value doesn't move. The rate, on the other hand, is charged on all {mine.cars} cars.
                {countSavings && <> On top of that, cash you keep back is earning {savingsRate.toFixed(1)}% in savings, which the
                deposit has to beat before it's worth anything.</>}
              </div>
            </div>

            <div className="rule" />
            <div className="lv-h">First car, in full</div>
            <div className="tblwrap">
              <table className="t">
                <thead><tr>
                  <th>Amount financed</th><th>Monthly × {T}</th><th>Balloon + fee</th>
                  <th>Paid if you hand it back</th><th>Paid if you buy it</th><th>Interest & fees</th>
                </tr></thead>
                <tbody><tr>
                  <td>{gbp(firstQuote.financed)}</td>
                  <td>{gbp(firstQuote.monthly, 2)}</td>
                  <td>{gbp(firstQuote.finalPayment)}</td>
                  <td>{gbp(firstQuote.costToChange)}</td>
                  <td>{gbp(firstQuote.totalPayable)}</td>
                  <td>{gbp(firstQuote.charge)}</td>
                </tr></tbody>
              </table>
            </div>
            {firstQuote.capped && (
              <div className="warn" style={{ marginTop: 12 }}>
                Your deposit is so big that the balloon would be worth more than the balance. No funder writes that, so the
                balloon has been trimmed to fit. Put less down and keep the rest.
              </div>
            )}
          </div>
        )}

        {/* ---------------- the grid ---------------- */}
        {tab === "grid" && (
          <div className="pane">
            <div className="pane-h cond">Every combination, side by side</div>
            <div className="pane-s">
              Deposit down the side, rate across the top. Each square is what that combination works out at over {horizon} years.
              Blue outline is the cheapest square on the board; black outline is where you are now.
            </div>

            <div className="chips" style={{ marginBottom: 12 }}>
              <button className={"chip" + (gridMetric === "cost" ? " on" : "")} onClick={() => setGridMetric("cost")}>
                {horizon}-year cost
              </button>
              <button className={"chip" + (gridMetric === "monthly" ? " on" : "")} onClick={() => setGridMetric("monthly")}>
                Monthly payment
              </button>
            </div>

            <div className="gwrap">
              <table className="g">
                <thead>
                  <tr>
                    <th className="corner">Deposit ↓ / APR →</th>
                    {grid.aprs.map((a) => <th key={a}>{a.toFixed(1)}%</th>)}
                  </tr>
                </thead>
                <tbody>
                  {grid.cells.map((row, ri) => (
                    <tr key={grid.dps[ri]}>
                      <th className="rh mono">
                        {gbp(grid.dps[ri])}
                        <small className="cond">{price ? ((grid.dps[ri] / price) * 100).toFixed(0) : 0}% of price</small>
                      </th>
                      {row.map((c) => {
                        const v = c[grid.key];
                        const isBest = Math.abs(v - grid.lo) < 0.5;
                        const isYou = c.d === dep && Math.abs(c.a - apr) < 0.001;
                        return (
                          <td key={c.a} style={{ background: shade(v) }}
                              className={(isBest ? "gc-best " : "") + (isYou ? "gc-you" : "")}>
                            <div className="gc-v">
                              {gridMetric === "cost" ? gbpK(v) : gbp(v, 0) + "/m"}
                            </div>
                            <div className="gc-d">
                              {isBest ? "cheapest" : "+" + gbpK(v - grid.lo)}
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="note">
              Read it across, not down. Moving one column left — a couple of points off the rate — shifts the number far more than
              moving several rows down. That's the whole point: the rate is the thing to shop for.
              {gridMetric === "monthly" && <> You're looking at the monthly payment right now, which is the one number that flatters a
              big deposit. Switch back to {horizon}-year cost to see what it really does.</>}
            </div>
            <div className="hint" style={{ marginTop: 10 }}>
              A 0% column isn't a fantasy — manufacturer offers land there regularly. What it usually costs you is the discount:
              a 0% deal at full list can lose to a 9.9% deal with money off. Put the discounted price in the box up top and compare.
            </div>
          </div>
        )}

        {/* ---------------- over time ---------------- */}
        {tab === "time" && (
          <div className="pane">
            <div className="pane-h cond">Cash out of your pocket, month by month</div>
            <div className="pane-s">
              Running totals of actual money paid, across {horizon} years. Replacement cars are priced up {infl.toFixed(1)}% a year.
              The buy-outright line is there for scale — it needs {gbp(cash.firstOutlay)} on day one and leaves you in a
              {" "}{(keepYears / 2).toFixed(1)}-year-old car on average, against {(changeYrs / 2).toFixed(1)} on the PCP cycle.
            </div>

            <div style={{ height: 260, marginBottom: 16 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timeline} margin={{ top: 6, right: 8, left: 0, bottom: 4 }}>
                  <CartesianGrid stroke={C.rule} strokeDasharray="2 3" vertical={false} />
                  <XAxis dataKey="m" {...axis} tickFormatter={(v) => `${Math.round(v / 12)}y`} />
                  <YAxis {...axis} tickFormatter={(v) => `£${(v / 1000).toFixed(0)}k`} width={54} />
                  <Tooltip content={<ChartTip />} />
                  <Legend wrapperStyle={{ fontSize: 11, fontFamily: "Roboto Condensed, Arial", letterSpacing: ".08em" }} />
                  <Line dataKey="you" name="YOUR DEAL" stroke={C.ink} strokeWidth={2.2} dot={false} />
                  <Line dataKey="rate" name={`RATE ${Math.max(0, apr - 3).toFixed(1)}%`} stroke={C.stamp} strokeWidth={2} dot={false} />
                  <Line dataKey="depo" name="DEPOSIT +£5,000" stroke={C.preprint} strokeWidth={2} dot={false} />
                  <Line dataKey="cash" name={`BUY OUTRIGHT, KEEP ${keepYears}Y`} stroke={C.gold} strokeWidth={2} strokeDasharray="5 3" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="lv-h">How often you change</div>
            <div className="tblwrap">
              <table className="t">
                <thead><tr>
                  <th>Change every</th><th>Cars</th><th>Avg age</th><th>Monthly</th>
                  <th>Cash in</th><th>Left in car</th><th>{costLabel}</th><th>Per month</th>
                </tr></thead>
                <tbody>
                  {freqs.map((f) => (
                    <tr key={f.T} className={f.T === T ? "here" : ""}>
                      <td>{f.T / 12} years</td>
                      <td>{f.cars}</td>
                      <td>{(f.T / 24).toFixed(1)} yr</td>
                      <td>{gbp(f.firstMonthly, 2)}</td>
                      <td>{gbp(f.cashIn)}</td>
                      <td>{gbp(f.residual)}</td>
                      <td className={Math.abs(f.trueCost - freqBest) < 0.5 ? "best" : ""}>{gbp(f.trueCost)}</td>
                      <td>{gbp(f.trueCost / horizonM, 2)}</td>
                    </tr>
                  ))}
                  <tr>
                    <td>Buy outright, keep {keepYears} yrs</td>
                    <td>{cash.cars}</td>
                    <td>{(keepYears / 2).toFixed(1)} yr</td>
                    <td>{gbp(cash.firstOutlay)} up front</td>
                    <td>{gbp(cash.cashIn)}</td>
                    <td>{gbp(cash.residual)}</td>
                    <td className={cash.trueCost < freqBest ? "best" : ""}>{gbp(cash.trueCost)}</td>
                    <td>{gbp(cash.trueCost / horizonM, 2)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="hint" style={{ marginTop: 10 }}>
              Check the average-age column before anyone waves the cheapest number around — these are not like-for-like cars.
              Handing back in negative equity costs nothing here, which is the guaranteed final value doing its job, and it's why
              a PCP can't leave you upside-down the way a long HP can.
            </div>
          </div>
        )}

        {/* ---------------- settings ---------------- */}
        {tab === "settings" && (
          <div className="pane">
            <div className="pane-h cond">Advanced settings</div>
            <div className="pane-s">
              These are set to sensible middle-of-the-road figures. Change them if you know better — a real funder's quote beats
              every estimate on this page.
            </div>

            <div className="setgrid">
              <div>
                <div className="setgrp">The car</div>
                <Field label="Annual mileage" value={mileage} onChange={setMileage} step={1000} min={2000} max={40000}
                       hint="More miles, lower guaranteed value, higher monthly." />
                <Field label="Car price inflation" value={infl} onChange={setInfl} suffix="% / yr" step={0.5} min={0} max={12}
                       hint="Each replacement car is priced up from today at this rate." />
              </div>

              <div>
                <div className="setgrp">The deal</div>
                <Field label="Deposit contribution" sub="dealer / brand" value={contrib} onChange={setContrib}
                       prefix="£" step={250} min={0}
                       hint="Not your money. It cuts the balance but never comes back to you." />
                <Field label="Cash added at each change" value={topUp} onChange={setTopUp} prefix="£" step={250} min={0}
                       hint="New money you put in on top of rolled-over equity when you swap." />
                <Field label="Option to purchase fee" value={optionFee} onChange={setOptionFee} prefix="£" step={5} min={0} />
              </div>

              <div>
                <div className="setgrp">Guaranteed final value</div>
                <Field label="Balloon set below forecast value" value={caution} onChange={(v) => setCaution(clamp(v, 0, 30))}
                       suffix="%" step={1} min={0} max={30}
                       hint={`Funders pitch the balloon under what the car should be worth. At ${T} months that's £${autoGmfv(price, T, mileage, caution).toLocaleString("en-GB")} on this car — the gap is the equity you get back.`} />
              </div>

              <div>
                <div className="setgrp">Your money</div>
                <button className={"chip" + (countSavings ? " on" : "")} onClick={() => setCountSavings(!countSavings)}
                        style={{ marginBottom: 9 }}>
                  {countSavings ? "Counting savings interest ✓" : "Count savings interest"}
                </button>
                <div className="hint" style={{ marginBottom: 12 }}>
                  On: cash you don't put down is assumed to sit in savings earning interest, and every figure is shown in today's
                  money. That's the only fair way to judge a deposit. Off: plain cash totals, which flatter big deposits.
                </div>
                <Field label="Your savings rate" value={savingsRate} onChange={setSavingsRate} suffix="%" step={0.1} min={0} max={15} />
                <Field label="Buy-outright comparison keeps car" value={keepYears}
                       onChange={(v) => setKeepYears(clamp(v, 2, 20))} suffix="years" step={1} min={2} max={20} />
              </div>
            </div>

            <button className="btn gh" onClick={resetAll}>Reset everything to defaults</button>
          </div>
        )}

        <div className="fine">
          <b>How the figures are worked out.</b> Payments monthly in arrears, first one a month after you drive away; APR converted
          to a monthly rate. The guaranteed final value is estimated from a mainstream depreciation curve and your mileage — the real
          one is set by the funder and can differ by thousands. Each deal runs its full term, the car goes back, and any equity above
          the balloon becomes the deposit on the next one.
          <span className="rule" style={{ display: "block", margin: "10px 0" }} />
          <b>Not included.</b> Excess mileage charges (usually 8–20p a mile over the allowance), damage beyond fair wear and tear,
          road tax after the first year, insurance, servicing, and any funder acceptance or admin fee. This is an illustration for
          weighing up options — it is not a quotation, and it is not financial advice.
        </div>
      </div>
    </div>
  );
}
